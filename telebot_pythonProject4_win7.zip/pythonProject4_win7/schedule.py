from pathlib import Path

import pandas as pd


# import os


def _get_xls_path_():
    # define there the plase where 'schedule.xlsx' Is located by this code-file
    # укажите тут место расположения 'schedule.xlsx' относительно этого файла
    xls_location = r'schedule.xlsx'
    q = Path(__file__).parent / xls_location
    # print(q.resolve())
    return q.resolve()


def get_xls_path_():
    return _get_xls_path_()


def _print_info_():
    # get info on This code-file
    print(f'It`s: {__file__}')
    print(f'Dir : {Path(__file__).parent.resolve()}')
    print(f'Pd  : {pd.__version__}')


def read_xls(path_xls) -> pd.DataFrame:
    # read XLS file to pandas.DataFrame
    if not path_xls.exists():
        return pd.DataFrame()
    _df = pd.read_excel(path_xls, sheet_name=0, header=0)
    return _df


def df_is_correct(_df: pd.DataFrame) -> bool:
    # Check If pd.DataFrame Is correct for the 'schedule.xlsx' titles
    # проверить pd.DataFrame schedule.xlsx' на соответсвие структуре
    # обрабатываемого файла с расписанием
    if not _df.ndim == 2:
        return False
    _col_names = "class	day	lesson_number	subject".split('\t')
    _column_names = set(_df.columns.tolist())
    for _col_name in _col_names:
        if _col_name not in _column_names:
            return False

    return True


def df_get_days(_df: pd.DataFrame) -> tuple:
    # get All [weekdays] from 'schedule.xlsx'
    # получить список всех учебных дней [weekdays] из файла 'schedule.xlsx'
    # предполагается, что дни недели указаны по-порядку
    _days = tuple(_df['day'].unique().tolist())
    return _days


# def _key_class(c_class: str) -> str:
#     dd = c_class[:2]
#     if dd == '10' or dd == '11':
#         return c_class
#     else:
#         return '0' + c_class


def df_get_classes(_df: pd.DataFrame) -> tuple:
    # Get All `Classes Names` from pd.DataFrame
    # Получить список всех клаасов, указанных в расcписании
    # отсортировать его по порядку классов (1 -> 11 )
    def clases_nums(x):
        return x if x[:2] == '10' or x[:2] == '11' else '0' + x

    def clases_nums_2(x):
        return int(x[:2]) if x[:2] == '10' or x[:2] == '11' else int(x[0])

    _cls = _df['class'].unique().tolist()
    _cls.sort(key=clases_nums)

    d = {}
    for i in range(5, 12):
        d[str(i)] = []
        for v in _cls:
            if clases_nums_2(v) == i:
                d[str(i)].append(v)

    # for x in _cls:
    #     print(f'{x}: key: {_key_class(x)}')

    return tuple(_cls), d


def df_get_data(_df: pd.DataFrame, _day: str, _cl: str):
    # Select Day TimeTable for defined `Weekday` and `Class`
    # print(_day, _cl)
    # Выбрать рассписание для указаного Дня и Класса
    _df2 = _df[(_df['class'] == _cl) & (_df['day'] == _day)] \
        [['lesson_number', 'subject']]
    # print(_df2)
    _df2 = _df2.set_index('lesson_number', drop=False)
    return _df2.sort_index()


def df_to_strings(_df) -> str:
    # Format 'lesson_number'+'subject' from pd.DataFrame
    # print(_df.head(3))
    # Отформатировать колонки 'lesson_number'+'subject' из строк pd.DataFrame
    # в строку (с переносами)

    # _t = [row for row in
    #       _df.itertuples(index=False, name=None)]
    _t = [f'{s.lesson_number:>2}  {s.subject:<20}' for s in
          _df.itertuples(index=False)]
    return '\n'.join(_t)


def _main():
    # A Set of checks of module functions
    # набор проверок функций модуля
    _print_info_()
    xls_path = _get_xls_path_()
    print(f'File "{xls_path}" Is Exists "{xls_path.exists()}"')
    df = read_xls(xls_path)
    print(f'df.shape := {df.shape}. Correct := {df_is_correct(df)}')
    print(f'df.head(10) := \n{df.head(10)}')
    print(f'Schedule Lists:')

    _days = df_get_days(df)
    print(f'days := \n{_days}')

    _classes = df_get_classes(df)
    print(f'classes := \n{_classes}\n')

    # test data extract:
    for x_day in _days[::2]:
        for x_class in _classes[0][1::3]:
            # print(x_class)
            _df3 = df_get_data(df, x_day, x_class)
            _t = df_to_strings(_df3)
            print(f"On `{x_day}` For `{x_class}` timetable Is:\n"
                  f"{_t}")
            # break
            # _t = _df3.to_string(header=False, index=True,
            #                     col_space=[10],
            #                     index_names=False,
            #                     justify='left'
            #                     )
            # print(f"On `{x_day}` For `{x_class}` timetable Is:\n"
            #       f"{_t}")


# test only ---
if __name__ == '__main__':
    _main()
