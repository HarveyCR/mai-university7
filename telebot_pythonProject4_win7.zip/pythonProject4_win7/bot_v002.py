﻿import sys
import datetime
import telebot
from telebot import types


import schedule
from menu import menu_data
from schedule import *
from replacements import replacements_data


# get timetable
df = schedule.read_xls(schedule.get_xls_path_())
t_clases = schedule.df_get_classes(df)

API_TOKEN = "7698664206:AAGsSvds7sUXSfHCvuf8VEIUS_DhlrrCuxw"  # 🔐 Укажите свой API токен

bot = telebot.TeleBot(API_TOKEN, num_threads=12, skip_pending =True, )

main_menu = types.ReplyKeyboardMarkup(resize_keyboard=True)
main_menu.add("📅 Расписание", "🔄 Замены", "🍽 Меню столовой")


@bot.message_handler(commands=['start'])
def send_welcome(message):
    print(f'Session ID: {message.chat.id} started at {datetime.datetime.now()}')
    print('-' * 10, datetime.datetime.now(), "-" * 20, file=sys.stderr)
    #print(f'{message}', file=sys.stderr)
    bot.send_message(message.chat.id, "👋 Привет! Выбери нужную опцию:", reply_markup=main_menu)


@bot.message_handler(func=lambda message: message.text == "📅 Расписание")
def choose_schedule_day(message):
    print(f'Session ID: {message.chat.id} Ask for "Расписание" at {datetime.datetime.now()}')
    send_day_selection(message, "📅 Выберите день недели для расписания:")


@bot.message_handler(func=lambda message: message.text == "🔄 Замены")
def choose_replacements_day(message):
    print(f'Session ID: {message.chat.id} Ask for "Замены" at {datetime.datetime.now()}')
    send_day_selection(message, "📌 Выберите день недели для замен:", replacements=True)


@bot.message_handler(func=lambda message: message.text == "🍽 Меню столовой")
def choose_menu_day(message):
    print(f'Session ID: {message.chat.id} Ask for "Меню столовой" at {datetime.datetime.now()}')
    send_day_selection(message, "🍽 Выберите день недели для меню столовой:", menu=True)


def send_day_selection(message, text, replacements=False, menu=False):
    # days = ["Понедельник", "Вторник", "Среда", "Четверг", "Пятница"]
    days = schedule.df_get_days(df)
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
    markup.add(*[types.KeyboardButton(day) for day in days])

    if replacements:
        bot.send_message(message.chat.id, text, reply_markup=markup)
        bot.register_next_step_handler(message, show_replacements)
    elif menu:
        bot.send_message(message.chat.id, text, reply_markup=markup)
        bot.register_next_step_handler(message, choose_menu_type)
    else:
        bot.send_message(message.chat.id, text, reply_markup=markup)
        bot.register_next_step_handler(message, choose_class)


def choose_class(message):
    day = message.text.replace("📅 ", "")
    class_buttons = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
    class_buttons.add("5", "6", "7", "8", "9", "10", "11")


    bot.send_message(message.chat.id, f"🎓 Выберите класс для {day}:", reply_markup=class_buttons)
    bot.register_next_step_handler(message, lambda msg: choose_subclass(msg, day))


def choose_subclass(message, day):
    selected_class = message.text
    subclass_buttons = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)

    # class_mapping = {
    #     "5": ["5А", "5Б", "5В"],
    #     "6": ["6А", "6Б", "6В", "6Г"],
    #     "7": ["7А", "7Б", "7ИТ", "7М"],
    #     "8": ["8А", "8Б", "8К", "8М"],
    #     "9": ["9А", "9М"],
    #     "10": ["10А"],
    #     "11": ["11А", "11М"]
    # }
    class_mapping = t_clases[1]
    # print(class_mapping)
    # print(selected_class)
    if selected_class in class_mapping:
        subclass_buttons.add(*class_mapping[selected_class])
        bot.send_message(message.chat.id, f"📝 Выберите класс {selected_class}:", reply_markup=subclass_buttons)
        bot.register_next_step_handler(message, lambda msg: show_schedule(msg, day, selected_class))
    else:
        bot.send_message(message.chat.id, "❌ Неверный класс. Выберите снова.", reply_markup=main_menu)


def show_schedule(message, day, selected_class):
    selected_subclass = message.text
    # print(day, selected_subclass)
    _df3 = df_get_data(df, day, selected_subclass)
    _t = df_to_strings(_df3)
    # print(f"On `{day}` For `{selected_subclass}` timetable Is:\n"
    #       f"{_t}")
    if len(_df3) == 0:
        bot.send_message(message.chat.id, f"📌 Расписание не найдено")
        return
    # schedule = schedule_data.get(day, {}).get(selected_subclass, "📌 Расписание не найдено")
    bot.send_message(message.chat.id, f"📅 Расписание на {day} ({selected_subclass}):\n{_t}")
    print(f'Session ID: {message.chat.id} Send data for "Расписание" for "{day}: {selected_subclass}" at {datetime.datetime.now()}')
    bot.send_message(message.chat.id, "⬇ Выберите другую опцию:", reply_markup=main_menu)


def show_replacements(message):
    day = message.text.replace("📅 ", "").lower()
    replacements = replacements_data.get(day, "✅ Нет замен")
    bot.send_message(message.chat.id, f"📌 Замены на {day}: {replacements}")
    bot.send_message(message.chat.id, "⬇ Выберите другую опцию:", reply_markup=main_menu)


def choose_menu_type(message):
    day = message.text.replace("📅 ", "")
    meal_buttons = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
    meal_buttons.add("🥞 Завтрак", "🍛 Обед")

    bot.send_message(message.chat.id, f"🍽 Выберите прием пищи на {day}:", reply_markup=meal_buttons)
    bot.register_next_step_handler(message, lambda msg: show_menu(msg, day))


def show_menu(message, day):
    meal_type = message.text.replace("🥞 ", "").replace("🍛 ", "").lower()
    menu = menu_data.get(day.lower(), {}).get(meal_type, "📌 Меню не найдено")
    bot.send_message(message.chat.id, f"🍽 {meal_type.capitalize()} на {day}: {menu}")
    bot.send_message(message.chat.id, "⬇ Выберите другую опцию:", reply_markup=main_menu)


if __name__ == '__main__':
    print(f'Starting {__file__} at {datetime.datetime.now()}....')
    try:
        bot.polling(none_stop=True, skip_pending=True, long_polling_timeout=30 )
    except Exception as err: 
        print(err, file=sys.stderr)
        # pass

    finally:
        print(f'Closing {__file__} at {datetime.datetime.now()}....')
